package one;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;


public class Petdisplay  implements ActionListener{
	JFrame jf;
	public static void main(String[] args) {
		new Petdisplay(). Petonsale();
	}
	public void Petonsale(){
		jf= new JFrame("PET STORE");
		jf.setLayout(new GridLayout(4,3));
		jf.setResizable(false);
		jf.setVisible(true);
		jf.setSize(800, 500);
		jf.setLocation(300, 200);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//JLabel p1 = new JLabel("ͼƬ��ַ");ͼƬ����̫�鷳�����ü�	
		    JPanel jp = new JPanel();
			jp.setLayout(new GridLayout(7,1));
			JLabel name=new JLabel(" name��dog");
			JLabel eat=new JLabel(" eat: bone");
			JLabel drink=new JLabel(" drink: water");
			JLabel live=new JLabel(" live: ground");
			JLabel hobby=new JLabel(" hobby:play");
			JLabel price=new JLabel("price:200");
			JButton b=new JButton("buy fish");
	        b.addActionListener(this);
		    jp.add(name);
		    jp.add(eat);
		    jp.add(drink);
		    jp.add(live);
		    jp.add(hobby);
		    jp.add(price);
		    jp.add(b);
		    jf.add(jp);
	    
	    JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(7,1));
		JLabel name1=new JLabel(" name��cat");
		JLabel eat1=new JLabel(" eat: fish");
		JLabel drink1=new JLabel(" drink: milk");
		JLabel live1=new JLabel(" live: roof");
		JLabel hobby1=new JLabel(" hobby:hug");
		JLabel price1=new JLabel("price:200");
		JButton b1=new JButton("buy fish");
        b1.addActionListener(this);
	    jp1.add(name1);
	    jp1.add(eat1);
	    jp1.add(drink1);
	    jp1.add(live1);
	    jp1.add(hobby1);
	    jp1.add(price1);
	    jp1.add(b1);
	    jf.add(jp1);
	    
	    JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(7,1));
		JLabel name2=new JLabel(" name��turtle");
		JLabel eat2=new JLabel(" eat:fish,shrimp");
		JLabel drink2=new JLabel(" drink: sea water");
		JLabel live2=new JLabel(" live: sea water");
		JLabel hobby2=new JLabel(" hobby:bask");
		JLabel price2=new JLabel("price:200");
		JButton b2=new JButton("buy turtle");
        b2.addActionListener(this);
	    jp2.add(name2);
	    jp2.add(eat2);
	    jp2.add(drink2);
	    jp2.add(live2);
	    jp2.add(hobby2);
	    jp2.add(price2);
	    jp2.add(b2);
	    jf.add(jp2);
	    
	    
	    JPanel jp3 = new JPanel();
		jp3.setLayout(new GridLayout(7,1));
		JLabel name3=new JLabel(" name��parrot");
		JLabel eat3=new JLabel(" eat: nuts,seeds");
		JLabel drink3=new JLabel(" drink: water");
		JLabel live3=new JLabel(" live: tree");
		JLabel hobby3=new JLabel(" hobby:fly");
		JLabel price3=new JLabel("price:200");
		JButton b3=new JButton("buy parrot");
        b3.addActionListener(this);
	    jp3.add(name3);
	    jp3.add(eat3);
	    jp3.add(drink3);
	    jp3.add(live3);
	    jp3.add(hobby3);
	    jp3.add(price3);
	    jp3.add(b3);
	    jf.add(jp3);
	    
	    JPanel jp4 = new JPanel();
		jp4.setLayout(new GridLayout(7,1));
		JLabel name4=new JLabel(" name��hamster");
		JLabel eat4=new JLabel(" eat: Sunflower seed");
		JLabel drink4=new JLabel(" drink: water");
		JLabel live4=new JLabel(" live: corner");
		JLabel hobby4=new JLabel(" hobby:eat");
		JLabel price4=new JLabel("price:200");
		JButton b4=new JButton("buy hamster");
        b4.addActionListener(this);
	    jp4.add(name4);
	    jp4.add(eat4);
	    jp4.add(drink4);
	    jp4.add(live4);
	    jp4.add(hobby4);
	    jp4.add(price4);
	    jp4.add(b4);
	    jf.add(jp4);
	    
	    JPanel jp5 = new JPanel();
		jp5.setLayout(new GridLayout(7,1));
		JLabel name5=new JLabel(" name��squirrel");
		JLabel eat5=new JLabel(" eat: pine cone");
		JLabel drink5=new JLabel(" drink: water");
		JLabel live5=new JLabel(" live: tree hole,underground");
		JLabel hobby5=new JLabel(" hobby:play");
		JLabel price5=new JLabel("price:200");
		JButton b5=new JButton("buy squirrel");
        b5.addActionListener(this);
	    jp5.add(name5);
	    jp5.add(eat5);
	    jp5.add(drink5);
	    jp5.add(live5);
	    jp5.add(hobby5);
	    jp5.add(price5);
	    jp5.add(b5);
	    jf.add(jp5);
	    
	    JPanel jp6 = new JPanel();
		jp6.setLayout(new GridLayout(7,1));
		JLabel name6=new JLabel(" name��rabbit");
		JLabel eat6=new JLabel(" eat: carrot");
		JLabel drink6=new JLabel(" drink: water");
		JLabel live6=new JLabel(" live: grassland,underground");
		JLabel hobby6=new JLabel(" hobby:eat");
		JLabel price6=new JLabel("price:200");
		JButton b6=new JButton("buy rabbit");
        b6.addActionListener(this);
	    jp6.add(name6);
	    jp6.add(eat6);
	    jp6.add(drink6);
	    jp6.add(live6);
	    jp6.add(hobby6);
	    jp6.add(b6);
	    jp6.add(price6);
	    jf.add(jp6);
	    
	    JPanel jp7 = new JPanel();
		jp7.setLayout(new GridLayout(7,1));
		JLabel name7=new JLabel(" name��snake");
		JLabel eat7=new JLabel(" eat:mouse");
		JLabel drink7=new JLabel(" drink: water");
		JLabel live7=new JLabel(" live: hole");
		JLabel hobby7=new JLabel(" hobby:bask");
		JLabel price7=new JLabel("price:200");
		JButton b7=new JButton("buy snake");
        b7.addActionListener(this);
	    jp7.add(name7);
	    jp7.add(eat7);
	    jp7.add(drink7);
	    jp7.add(live7);
	    jp7.add(hobby7);
	    jp7.add(price7);
	    jp7.add(b7);
	    jf.add(jp7);
	    
	    JPanel jp8 = new JPanel();
		jp8.setLayout(new GridLayout(7,1));
		JLabel name8=new JLabel(" name��lizard");
		JLabel eat8=new JLabel(" eat: bug");
		JLabel drink8=new JLabel(" drink: water");
		JLabel live8=new JLabel(" live: tree");
		JLabel hobby8=new JLabel(" hobby:bask");
		JLabel price8=new JLabel("price:200");
		JButton b8=new JButton("buy lizard");
        b8.addActionListener(this);
	    jp8.add(name8);
	    jp8.add(eat8);
	    jp8.add(drink8);
	    jp8.add(live8);
	    jp8.add(hobby8);
	    jp8.add(price8);
	    jp8.add(b8);
	    jf.add(jp8);
	    
	    JPanel jp9 = new JPanel();
		jp9.setLayout(new GridLayout(7,1));
		JLabel name9=new JLabel(" name��fish");
		JLabel eat9=new JLabel(" eat:aquatic plant");
		JLabel drink9=new JLabel(" drink: water");
		JLabel live9=new JLabel(" live: water");
		JLabel hobby9=new JLabel(" hobby:swim");
		JLabel price9=new JLabel("price:200");
		JButton b9=new JButton("buy fish");
        b9.addActionListener(this);
	    jp9.add(name9);
	    jp9.add(eat9);
	    jp9.add(drink9);
	    jp9.add(live9);
	    jp9.add(hobby9);
	    jp9.add(price9);
	    jp9.add(b9);
	    jf.add(jp9);
	    
	    JPanel jp10 = new JPanel();
		jp10.setLayout(new GridLayout(7,1));
		JLabel name10=new JLabel(" name��myna");
		JLabel eat10=new JLabel(" eat: earthworm");
		JLabel drink10=new JLabel(" drink: water");
		JLabel live10=new JLabel(" live: tree");
		JLabel hobby10=new JLabel(" hobby:fly");
		JLabel price10=new JLabel("price:200");
		JButton b10=new JButton("buy myna");
        b10.addActionListener(this);
	    jp10.add(name10);
	    jp10.add(eat10);
	    jp10.add(drink10);
	    jp10.add(live10);
	    jp10.add(hobby10);
	    jp10.add(price10);
	    jp10.add(b10);
	    jf.add(jp10);
	    
	    JPanel jp11 = new JPanel();
		jp11.setLayout(new GridLayout(7,1));
		JLabel name11=new JLabel(" name��canary");
		JLabel eat11=new JLabel(" eat: millet");
		JLabel drink11=new JLabel(" drink: water");
		JLabel live11=new JLabel(" live: tree");
		JLabel hobby11=new JLabel(" hobby:sing");
		JLabel price11=new JLabel("price:200");
		JButton b11=new JButton("buy canary");
        b11.addActionListener(this);
	    jp11.add(name11);
	    jp11.add(eat11);
	    jp11.add(drink11);
	    jp11.add(live11);
	    jp11.add(hobby11);
	    jp11.add(price11);
	    jp11.add(b11);
	    jf.add(jp11);
	    
	  
		/*JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(6,1));
		String dog = "dog";
		String bone = "bone";
		String water = "water";
		String ground = "ground";
		String play = "play";
		Petinfo(dog,bone,water,ground,play);
		JButton b1=new JButton("get the pet");
		   
			jp1.add(name1);
		    jp1.add(eat1);
		    jp1.add(drink1);
		    jp1.add(live1);
		    jp1.add(hobby1);
		    jp1.add(b1);
		    jf.add(jp1);*/

	}
	public void actionPerformed(ActionEvent e){
		JOptionPane.showConfirmDialog(
				jf, // ���Ϊnull���˿����ʾ�����룬Ϊjf����ʾΪjf������
				"Buy success��\n"
						+ new String("you got the pet"),
				"Thank you for your consumption", JOptionPane.DEFAULT_OPTION);
//System.out.println(comm);
	
	}
	/*public static void Petinfo(String name,String eat,String drink,String live,String hobby){
		JLabel name1=new JLabel(name);
		JLabel eat1=new JLabel(eat);
		JLabel drink1=new JLabel(drink);
		JLabel live1=new JLabel(live);
		JLabel hobby1=new JLabel(hobby);
		
	}*/
}
